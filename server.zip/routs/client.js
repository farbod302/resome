const express = require('express')
const router = express.Router();
var uniqid = require('uniqid');
const Client = require('../db-models/client');
const jwt = require('jsonwebtoken');
const { checkUser, checkBody } = require('./helperFunctions');
const OpUser = require('../db-models/opUser');



router.post('/add_client', (req, res) => {
    const { apiKey } = req.body
    if (!apiKey || apiKey !== process.env.API_KEY) {
        res.json(false)
        return
    }
    else {
        const { name, phone, password } = req.body
        const nc = new Client({
            name, phone, password,
            userName: uniqid(),
        })

        nc.save().then((result) => {
            res.json(result.userName)
        })
    }
})

router.post('/log_in', (req, res) => {
    const { userName, password } = req.body
    Client.findOne({ name: userName, password: password }).then(result => {

        if (!result) {
            res.json(false)
            return
        }
        else {
            const token = jwt.sign({
                name: userName,
                userName: result.userName
            }, process.env.JWT_KEY)
            res.json(token)
            return
        }

    })
})


router.post('/add_user', (req, res) => {
    const { client, name, lastName, id, img, sDate, eDate, allow } = req.body
    var user = {
        name: name,
        lastName: lastName,
        img,
        timeLimit: false
    }
    var uid = uniqid()
    { id !== "" ? user['id'] = id : user['id'] = uid }
    { allow ? user['allow'] = allow : user['allow'] = true }
    if (sDate && eDate) {
        user['sDate'] = sDate
        user['eDate'] = eDate
        user['timeLimit'] = true
    }
    var duplicate
    Client.findOne({ userName: client }).then(result => {
        if (!result) {
            res.json(false)
            return
        }
        async function check() {
            duplicate = await checkUser(result.users, user.id)
            if (duplicate) {
                res.json(false)
                return
            }
            else {
                result.users.push(user)
                result.save().then(() => {
                    const op = new OpUser({
                        client, userId: user.id,
                        op: 0
                    })
                    op.save().then(() => {
                        res.json(true)
                        return
                    })
                })
            }
        }
        check()
    })
})


router.post('/get_users', (req, res) => {
    Client.findOne({ userName: req.body.client }, { users: 1 }).then(result => {
        if (result) {
            var users = result.users
            users.map(each => {
                delete each['img']
            })
            res.json(users)
            return
        }
        res.json(false)
        return
    })
})


router.post('/edit_user', (req, res) => {
    const { client, userId, name, lastName, img, allow, sDate, eDate } = req.body

    Client.findOne({ userName: client }).then(result => {
        if (!result) {
            res.json(false)
            return
        }
        var users = [...result.users]
        var user = users.find(each => each.id === userId)
        if (!user) {
            res.json(false)
            return
        }
        user = checkBody(name, user, "name")
        user = checkBody(lastName, user, "lastName")
        if (img !== null) {
            user = checkBody(img, user, "img")
            console.log("ok");
        }
        user = checkBody(allow, user, "allow")
        user = checkBody(sDate, user, "sdate")
        user = checkBody(eDate, user, "eDate")
        if (sDate) {
            user["timeLimit"] = true
        }
        for (var propName in user) {
            if (user[propName] === null || user[propName] === undefined) {
                delete user[propName];
            }
        }
        var index = result.users.findIndex(each => each.id === userId)
        users[index] = user

        Client.findOneAndUpdate({ userName: client }, { $set: { users: users } }).then(() => {
            const op = new OpUser({
                client, userId,
                op: 1,
            })
            op.save().then(() => {
                res.json(
                   true
                )
                return
            })
        })


    })

})


router.post('/allow_users', (req, res) => {
    const { client } = req.body
    Client.findOne({ userName: client }).then(result => {
        if (!result) {
            res.json(false)
            return
        }
        var users = [...result.users]
        var filtered = users.filter(each => each.allow === true)
        var allowIds = []
        filtered.forEach(each => {
            allowIds.push(each.id)
        })
        res.json(allowIds)
    })

})



router.post('/delete_user', (req, res) => {
    const { client, userId } = req.body
    Client.findById(client).then(result => {
        if (!result) {
            res.json(false)
            return
        }
        var users = { ...result.users }
        var filterd = users.filter(each => each.id !== userId)
        result.users = filterd
        result.save().then(() => {
            const newOp = new OpUser({
                client,
                userId,
                op: 2,
            })
            newOp.save().then(() => {
                res.json(true)
                return
            })
        })
    })

})





module.exports = router