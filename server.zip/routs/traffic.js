const express = require('express')
const router = express.Router();

const Client = require('../db-models/client')



router.post('/new_traffic', (req, res) => {

    const { client, user, status } = req.body

    const traffic = {
        user,
        status,
        date: new Date()
    }
    Client.findOneAndUpdate({ userName: client }, { $push: { traffics: traffic } }).then((result) => {
        if (result) {
            res.json(true)
            return
        }
        res.json(false)
        return
    })

})



module.exports = router