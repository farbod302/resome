const express = require("express")
const router = express.Router();
const Client = require('../db-models/client');
const { getIds } = require("./helperFunctions");



router.post('/traffic', (req, res) => {

    const { client, userId, status } = req.body
    var socket = req.app.get('socket')
    var date = Date.now()
    Client.findOne({ userName: client }).then(result => {
        if (!result) {
            res.json(false)
            return
        }
        else {
            result.traffics.push({
                userId,
                status,
                date
            })
            var minate = new Date(date).getMinutes()
            if (minate < 10) {
                minate = `0${minate}`
            }

            var houre = new Date(date).getHours()
            if (houre < 10) {
                houre = `0${houre}`
            }
            var users = [...result.users]
            var user = users.find(each => each.id === userId)
            result.save().then(() => {
                var sendData = {
                    name: user.name,
                    lastName: user.lastName,
                    time: houre + ":" + minate,
                    date,
                    status,
                    img: user.img
                }
                var ids = getIds(client)
                if (ids.length > 0) {
                    ids.map((each) => {
                        socket.to(each).emit('new_traffic', sendData)
                    })
                }
                res.json(true)

            })
        }
    })

})


module.exports = router