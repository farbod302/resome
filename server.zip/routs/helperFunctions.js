const checkUser = (users, id) => {
    return new Promise(resolve => {
        users.forEach(each => {
            if (each.id === id) resolve(true)
        })
        resolve(false)
    })
}

const checkBody = (value, user, element) => {
    if (value !== undefined || value !== null) {
        user[element] = value
        return user
    }
    else return user
}


var users = []

const addUserTosocket = (client, id) => {

    var index = users.findIndex(each => each.client === client)
    if (index !== -1) {
        users[index].ids.push(id)
    }
    else {
        users.push({
            client: client,
            ids: [id]
        })
    }
}

const removeUserFromSocket = (socketId) => {
    var index = users.findIndex(each => each.ids.includes(socketId))
    if (index !== -1) {

        var newIds = users[index].ids.filter(each => each !== socketId)
        if (newIds.length === 0) {
            users.splice(index, 1)
        }
        else {
            users[index].ids = newIds
        }
    }
}
const getIds = (clientId) => {
    var client = users.find(each => each.client === clientId)
    if (client) {
        return client.ids
    }
    else {
        return []
    }
}
module.exports = { checkUser, checkBody, addUserTosocket, removeUserFromSocket, getIds }