const express = require("express")
const cors = require("cors")
const mongoose = require("mongoose")
const bodyParser = require("body-parser")
const io = require("socket.io")
const http = require("http")
require('dotenv').config()
const app = express()
const server = http.createServer(app);
const { addUserTosocket, removeUserFromSocket } = require("./routs/helperFunctions")


app.use(cors())
app.use(bodyParser.json({limit: "1mb"}))
app.use(bodyParser.urlencoded({
    limit: '1mb',
    extended: true,
    parameterLimit: 50000
}))

const socket = io(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
})
app.set('socket', socket)


server.listen(process.env.PORT, console.log(`Server Start On Port ${process.env.PORT}`))

mongoose.connect(process.env.DB_CONNECTION, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useFindAndModify: false
}).then(() => {
    console.log("Connect To db Successfully")
})



socket.on('connection', mySocket => {
    mySocket.on('join', (data) => {
        addUserTosocket(data, mySocket.id)
    })
    mySocket.on('disconnect', () => {
        removeUserFromSocket(mySocket.id)
    })
})




const client = require('./routs/client')
const traffic = require('./routs/traffic')
const gate = require('./routs/gate')

app.use('/client', client)
app.use('/traffic', traffic)
app.use('/gate', gate)