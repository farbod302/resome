const mongoose = require("mongoose")



const opUser = mongoose.Schema({
    client: String,
    userId: String,
    op: Number,
    don: {
        type: Boolean,
        defult: false
    }
})


module.exports = mongoose.model("UserOp", opUser)