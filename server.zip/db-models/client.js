const mongoose = require("mongoose")



const client = mongoose.Schema({

    name: String,
    phone: String,
    userName: String,
    password: String,
    users: {
        type: Array,
        default: []
    },
    traffics: {
        type: Array,
        default: []
    }
})


module.exports = mongoose.model("Client", client)